package com.annathe.training.loggingexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoggingExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
