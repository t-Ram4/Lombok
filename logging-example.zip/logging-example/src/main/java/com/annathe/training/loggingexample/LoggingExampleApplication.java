package com.annathe.training.loggingexample;

import org.apache.commons.logging.LogFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication

@RestController
public class LoggingExampleApplication {

	Logger log = LoggerFactory.getLogger(LoggingExampleApplication.class);
	
	
	
	@GetMapping("greeting/{name}")
	public String greetings(@PathVariable String name) {
		
		String request = name;
		
		log.debug("Request {}", request);
		
		String response = "Hi" +name;
		
		log.debug("response {}", response);
		
		return response;
		
	}
	
	public static void main(String[] args) {
		SpringApplication.run(LoggingExampleApplication.class, args);
	}

}
