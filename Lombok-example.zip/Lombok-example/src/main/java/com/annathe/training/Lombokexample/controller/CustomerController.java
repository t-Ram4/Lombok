package com.annathe.training.Lombokexample.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.annathe.training.Lombokexample.model.Customer;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CustomerController {
	
	@GetMapping("customers/dummy")
	
	public Customer getDummyCustomer() {
		
		log.info("inside getDummyCustomer() method");
		
		Customer customer  = new Customer();
		customer.setId("cus01");
		customer.setName("Yogesh");
		
		
		return customer;
		
	}
	

}
