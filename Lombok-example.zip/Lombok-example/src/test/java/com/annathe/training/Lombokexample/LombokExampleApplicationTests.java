package com.annathe.training.Lombokexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LombokExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
